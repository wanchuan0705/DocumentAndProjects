﻿namespace CoreCms.Net.Mapping
{
    internal interface AutoMapperIProfile
    {
    }
}
