using CoreCms.Net.Model.Entities;

namespace CoreCms.Net.IRepository
{
    /// <summary>
    ///     商品类型属性值表 工厂接口
    /// </summary>
    public interface ICoreCmsGoodsTypeSpecValueRepository : IBaseRepository<CoreCmsGoodsTypeSpecValue>
    {
    }
}