using CoreCms.Net.Model.Entities;

namespace CoreCms.Net.IRepository
{
    /// <summary>
    ///     提交表单保存大文本值表 工厂接口
    /// </summary>
    public interface ICoreCmsFormSubmitDetailRepository : IBaseRepository<CoreCmsFormSubmitDetail>
    {
    }
}